from tkinter import*
import sqlite3

root=Tk()
root.title("Contact form")
root.iconbitmap("D:\Zoho assignment\contactimg.ico")
root.geometry("600x470")
Label(root,text="Contact form ",font="arial 30").place(x=200,y=50)
#databases
#Create a database or connect to one
conn=sqlite3.connect("contacts.db")

#create cursor
c=conn.cursor()

#create table
c.execute("""CREATE TABLE contacts (Name text,Phno text,Email text)""")


# create submit function for database
def submit():
    conn = sqlite3.connect('contacts.db')

    #creae cursor
    c=conn.cursor
    #insert tnto table
    c.execute("INSERT INTO addresses VALUES(:NameEntry,:PhnoEntry,:EmailEntry)",
    {
        NameEntry: NameEntry.get(),
        PhnoEntry: PhnoEntry.get(),
        EmailEntry: EmailEntry.get()
    })
    #Commit Changes
    conn.commit()

    #close connection
    conn.close()
    
    #clear the textboxes
    NameEntry.delete(0,END)
    PhnoEntry.delete(0,END)
    EmailEntry.delete(0,END)

Name_Label=Label(text="Name", font=23).place(x=100,y=150)
Phno_Label=Label(text="Phno", font=23).place(x=100,y=200)
Email_label=Label(text="Email", font=23).place(x=100,y=250)

#=====ENTRY=========
Namevalue=StringVar()
Phnovalue=StringVar()
Emailvalue=StringVar()

NameEntry=Entry(root,textvariable=Emailvalue,width=30,bd=2,font=20).place(x=200,y=150)
PhnoEntry=Entry(root,textvariable=Phnovalue,width=30,bd=2,font=20).place(x=200,y=200)
EmailEntry=Entry(root,textvariable=Emailvalue,width=30,bd=2,font=20).place(x=200,y=250)

Button(text="Save", command="submit", font=20, width=11,height=2).place(x=250,y=300)

#Commit Changes
conn.commit()

#close connection
conn.close()

root.mainloop()