from tkinter import*


root=Tk()
root.title("Signup")
root.iconbitmap("D:\Zoho assignment\contactimg.ico")
root.geometry("600x470")
root.resizable(0,0)
#========
def open():
    top=Toplevel()
    top.title("Signin")
    top.iconbitmap("D:\Zoho assignment\contactimg.ico")
    top.geometry("600x470")
    Label(top,text="Signin",font="arial 25").pack(pady=50)
    Label(top,text="Don't have an account ?signup ",font="arial 10").place(x=200,y=100)


    Label(top,text="Email", font=23).place(x=100,y=150)
    Label(top,text="Password", font=23).place(x=100,y=200)

    #=====ENTRY=========
    Emailval=StringVar()
    Passwordval=StringVar()

    EmailEntry=Entry(top,textvariable=Emailval,width=30,bd=2,font=20).place(x=200,y=150)
    PasswordEntry=Entry(top,textvariable=Passwordval,show="*",width=30,bd=2,font=20).place(x=200,y=200)

    Button(top,text="Signin", font=20, width=11,height=2).place(x=250,y=300)

    top.mainloop()



Label(root,text="Signup",font="arial 25").pack(pady=50)
Label(root,text="aldready have an account ? ",font="arial 10").place(x=200,y=100)
Label(root,text="By clicking the ""sign Up"" button, ",font="arial 10").place(x=200,y=350)
Label(root,text=" you are creating an account, and agree the Terms of Use",font="arial 10").place(x=180,y=370)
btn=Button(root,text="Signin",command=open).place(x=370,y=100)

Label(text="Email", font=23).place(x=100,y=150)
Label(text="Password", font=23).place(x=100,y=200)
Label(text="Secret", font=23).place(x=100,y=250)

#=====ENTRY=========
Emailvalue=StringVar()
Passwordvalue=StringVar()
Secretvalue=StringVar()

EmailEntry=Entry(root,textvariable=Emailvalue,width=30,bd=2,font=20).place(x=200,y=150)
PasswordEntry=Entry(root,textvariable=Passwordvalue,show="*",width=30,bd=2,font=20).place(x=200,y=200)
SecretEntry=Entry(root,textvariable=Secretvalue,width=30,show="*",bd=2,font=20).place(x=200,y=250)

Button(text="Signup", font=20, width=11,height=2).place(x=250,y=300)

root.mainloop()

